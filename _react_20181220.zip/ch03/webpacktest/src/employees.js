var employees = [ 
    { name : '홍길동', email:'gdhong@opensg.net', mobile:'010-2222-3331' },
    { name : '이몽룡', email:'mrlee@opensg.net', mobile:'010-2222-3332' },
    { name : '성춘향', email:'chsung@opensg.net', mobile:'010-2222-3333' },
    { name : '박문수', email:'mspark@opensg.net', mobile:'010-2222-3334' },
    { name : '변학도', email:'hdbyun@opensg.net', mobile:'010-2222-3335' }
];
module.exports = employees;
