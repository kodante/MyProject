const styles = {
    listItemStyle : {
       fontStyle:"italic", textDecoration:"underline"
    },
    dashStyle: {
       backgroundColor: "#fff",
       borderTop: "2px dashed gray"
    }
}
export default styles;