import React, { Component } from 'react';
import CountryItem from "./CountryItem";

class CountryList extends Component {
    render() {
        let countries = this.props.countries.map((item,index)=> {
            return (
                /*<li key={item.no} className={item.visited ? "list-group-item active" : "list-group-item" }>
                {item.country} - {index}
                </li>*/
                <CountryItem key={item.no} country={item} />
            )
        });
        return (
            <div>
                <ul className="list-group">{countries}</ul>
            </div>
        );
    }
}

export default CountryList;