import React, { Component } from 'react';
import Title from "./Title";
import CountryList from "./CountryList";
import styles from "./Styles";
import Footer from "./Footer";

class app extends Component {
    constructor(props) {
        super(props);
        this.state = {
            msg : "world!!!",
            list : [
                { no:1, country:'이집트', visited:false },
                { no:2, country:'일본',  visited:true },
                { no:3, country:'피지', visited:false },
                { no:4, country:'콜롬비아', visited:true }
            ]
        }
    }


    createString(x, y) {
        return (
            <div className="well">{x} + {y} = {x+y}</div>
        )
    }
    render() {
        let data = { title : "해야할일 목록"};
        return (
            <div className="container">
                <h1 >Hello, {this.state.msg}</h1>
                <hr style={styles.dashStyle} />
                { this.createString(4,6) }
                <Title title={data.title} />   
                <div>{ Title(data) }</div>
                <CountryList countries={this.state.list}/>
                <Footer />
            </div>
        );
    }
}

export default app;