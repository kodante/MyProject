import React, { Component } from 'react';
import styles from './Styles';

class CountryItem extends Component {
    render() {
        let item = this.props.country;
        let countryClass = '';
        if (item.visited) {
            countryClass = 'list-group-item active';
        } else {
            countryClass = 'list-group-item';
        }

        return (
            <div>
                <li style={styles.listItemStyle} className={countryClass}>
                    {item.country}                
                </li>
            </div>
        );
    }
}

export default CountryItem;