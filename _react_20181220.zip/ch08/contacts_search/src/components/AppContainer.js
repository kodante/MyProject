import App from './App';
import ContactActionCreator from '../actions/ContactActionCreator';
import {connect} from 'react-redux';

const mapState = (state) => {
    return {
        contacts: state.contacts,
        isLoading: state.isLoading,
        name: state.name,
        showAddContact: state.showAddContact
    }
}

const mapDispatch = (dispatch) => {
    console.log("### mapDispatch - " + ContactActionCreator.asyncAddContact);
    return {
        changeShowAddContact : (isShow) => dispatch(ContactActionCreator.changeShowAddContact(isShow)),
        changeName : (name) => dispatch(ContactActionCreator.changeName(name)),
        addContact : (name,tel,address) => dispatch(ContactActionCreator.asyncAddContact(name,tel,address)),
        deleteContact : (no) => dispatch(ContactActionCreator.asyncDeleteContact(no)),
        searchContact : () => dispatch(ContactActionCreator.asyncSearchContact()),
    }
}

const AppContainer = connect(mapState, mapDispatch)(App);

export default AppContainer;