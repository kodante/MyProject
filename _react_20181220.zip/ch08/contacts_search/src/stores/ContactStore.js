import { createStore, applyMiddleware } from 'redux';
import ContactReducer from '../reducers/ContactReducer';
import ContactActionCreator from '../actions/ContactActionCreator';
import reduxThunk from 'redux-thunk';

import {composeWithDevTools} from 'redux-devtools-extension';
import invariant from 'redux-immutable-state-invariant';
import _ from 'lodash';

const logger = (store) => (next) => (action) => {
    if (typeof(action) !== 'undefined' &&
        typeof(action) !== 'function' ) {
            console.log('### action 시랭 : ", action');
    }
    next(action);
}


//const ContactStore = createStore(ContactReducer, applyMiddleware(logger, reduxThunk));

const composeEnhancers = composeWithDevTools( _.extend( ContactActionCreator ))
const ContactStore = createStore(ContactReducer, composeEnhancers( applyMiddleware(invariant(), reduxThunk, logger )) );

export default ContactStore;
