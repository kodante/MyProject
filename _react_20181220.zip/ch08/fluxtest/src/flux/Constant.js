export default {
  CHANGE_NAME : "change name",
  ADD_ITEM : "add item",
  DELETE_ITEM : "delete item"
}