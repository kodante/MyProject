export default {
    ADD_TODO : "add todo",
    DELETE_TODO : "delete todo",
    TOGGLE_DONE : "toggle done",
    CHANGE_TIME : "change time"
}