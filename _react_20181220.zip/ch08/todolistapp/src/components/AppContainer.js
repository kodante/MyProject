import App from './App';
import TodoActionCreator from '../redux/TodoActionCreator';
import TimeActionCreator from '../redux/TimeActionCreator';
import { connect } from 'react-redux';

const mapState = function(state) {
    return {
        todolist : state.todolist,
        currentTime : state.currentTime
    }
}

const mapDispatch = function(dispatch) {
    return {
        addTodo: (todo)=> dispatch(TodoActionCreator.addTodo(todo)),
        deleteTodo: (no)=> dispatch(TodoActionCreator.deleteTodo(no)),
        toggleDone:(no)=> dispatch(TodoActionCreator.toggleDone(no)),
        changeTime: () => dispatch(TimeActionCreator.asyncChangeTime())
    }
}

const AppContainer = connect(mapState, mapDispatch)(App);
export default AppContainer;
