import { createStore, applyMiddleware } from 'redux';
import RootReducer from './RootReducer';
import thunk from 'redux-thunk';


const logger = (store)=>(next) => (action) => {
    //console.log("---------------------");
    if (typeof(action) !== "function") {
        console.log("## action: ", action);
    }    
    //console.log("## before: ", store.getState());
    let actionAfter = next(action);
    //console.log("## after: ", store.getState());
    //return actionAfter;
}

const TodoStore = createStore(RootReducer, applyMiddleware(logger, thunk));
export default TodoStore;
;

