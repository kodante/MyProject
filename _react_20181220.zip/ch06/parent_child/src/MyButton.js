import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import Logger from './Logger';

class MyButton extends PureComponent {

    render() {
        console.log("### MyButton render");
        return (
            <div>
                <button className="btn btn-primary" onClick={()=>this.props.addItem()}>AddItem!</button>
            </div>
        );
    }
}

MyButton.propTypes = {
    addItem : PropTypes.func.isRequired
};

export default Logger(MyButton);