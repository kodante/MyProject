import { generateRandom } from './utility'
console.log(generateRandom());

