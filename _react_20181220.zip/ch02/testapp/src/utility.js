let c = 100;

function sum(a,b) {
    return a+b+c;
}

//export { sum };
export default sum;

