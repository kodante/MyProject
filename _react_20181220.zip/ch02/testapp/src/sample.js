let name = "world";
console.log(`hello ${name}!!`);
