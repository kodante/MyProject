//import { sum } from './utility';
import sum from './utility';

console.log(sum(1,2));
