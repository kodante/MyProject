export default {
  SEARCH_REQUEST : 'search contact request',
  SEARCH_SUCCESS : 'search contact success',
  SEARCH_FAIL : 'search contact fail',
  
  CHANGE_ISLOADING : 'change isloading',
  //CHANGE_SHOW_ADD_CONTACT : 'change show add contact form',
  CHANGE_NAME : 'change name'
}