import Constant from '../Constant';
import axios from 'axios';

const BASEURL = ""; // proxy

const ContactActionCreator = {
    changeName(name) {
        return { type: Constant.CHANGE_NAME, payload : {name:name} };
    },

    searchContactRequest(name) {
        return { type: Constant.SEARCH_REQUEST, payload: {name:name} };
    },

    searchContactSuccess(contacts) {
        return { type: Constant.SEARCH_SUCCESS, payload: {contacts : contacts} };
    },

    searchContactFail() {
        return { type:Constant.SEARCH_FAIL };
    },

    changeIsLoading(isLoading) {
        return { type: Constant.CHANGE_ISLOADING, payload: {isLoading : isLoading} } ;
    },
    // changeShowAddContact(showAddContact) {
    //     return { type: Constant.CHANGE_SHOW_ADD_CONTACT, payload: {showAddContact: showAddContact} };
    // },

    asyncSearchContact() {
        console.log("#### asyncSearchContact!!");
        return (dispatch, getState) => {
            console.log("#### asyncSearchContact1");
            let {name} = getState();
            console.log("#### asyncSearchContact name " + name);
            if (name.length >=2 ) {
                dispatch(this.searchContactRequest(name));
                console.log("#### asyncSearchContact3");
                axios.get(BASEURL + '/contacts_long/search/' + name)
                .then((response)=> {
                    console.log("#### asyncSearchContact - " + response.data);
                    dispatch(this.searchContactSuccess(response.data));
                })
                .catch((error)=> {
                    dispatch(this.searchContactFail());
                })
            }
        }
    },

    asyncAddContact(name, tel, address) {
        console.log("#### asyncAddContact!!");

        return (dispatch, getState) => {
            dispatch(this.changeName(name));
            dispatch(this.changeIsLoading(true));
            console.log("#### asyncAddContact!!" + BASEURL + '/contacts' + {name:name, tel:tel, address:address} );
            console.log("#### asyncAddContact!!" +'name : ' + name +  tel + address );
            axios.post(BASEURL + '/contacts' , {name:name, tel:tel, address:address})
            .then((response)=> {
                //dispatch(this.changeShowAddContact(false));
                if (response.data.status === 'success') {
                    dispatch(this.changeIsLoading(false));
                    dispatch(this.asyncSearchContact()); 
                } else {
                    dispatch(this.changeIsLoading(false));
                }
            })
            .catch((error)=> {
                dispatch(this.changeIsLoading(false));;
            })
        }
    },

    asyncDeleteContact(no) {
        return (dispatch) => {
            dispatch(this.changeIsLoading(true));
            axios.delete(BASEURL + '/contacts/' + no)
            .then((response)=> {
                dispatch(this.changeIsLoading(false));
                dispatch(this.asyncSearchContact());
            })
            .catch((error)=> {
                dispatch(this.changeIsLoading(false));;
            })
        }
    }

}

export default ContactActionCreator;