import React, { Component } from 'react';

class App2 extends Component {
    constructor(props) {
        super(props);
        this.state = { x: 0, y : 0 };
    }

    add = () => {
        //this.refs.ix.value; // 옛날 방식
        //console.log(this.refs.ix.value);
        let x = parseInt(this.ix.value);
        let y = parseInt(this.iy.value);

        this.setState({x : x, y:y});
    }
    
    render() {
        return (
            <div>
            x : <input id="x" ref={(input)=>{this.ix = input}} type="text" defaultValue={this.state.x} /><br/>
            y : <input id="y" ref={(input)=>{this.iy = input}} type="text" defaultValue={this.state.y} /><br/>
            <button onClick={this.add}>Add</button><br/>
            result : <span>{this.state.x + this.state.y}</span>
          </div>
        );
    }
}

export default App2;