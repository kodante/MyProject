import React, { Component } from 'react';
import App from './App';
import App2 from './App2';

class AppG extends Component {
    render() {
        return (
            <div>
                <App />
                <App2 />
            </div>
        );
    }
}

export default AppG;