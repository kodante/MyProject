import React, { Component } from 'react';
import PropTypes from 'prop-types';

class MyButton extends Component {
    render() {
        return (
            <div>
                <button className="btn btn-primary" onClick={()=>this.props.addItem()}>AddItem!</button>
            </div>
        );
    }
}

MyButton.propTypes = {
    addItem : PropTypes.func.isRequired
};

export default MyButton;